﻿using BTCN_PhamAnhDao_1851050029.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BTCN_PhamAnhDao_1851050029.BUS;

namespace BTCN_PhamAnhDao_1851050029
{
    public partial class FCTDatHang : Form
    {
        public int maDH;
        public int maSP;
        BUS_SanPham busSP;
        private bool co = false;
        DataTable tbDonHang;


        Form chuyenForm;
        public Form ChuyenForm
        {
            set { chuyenForm = value; }
        }
        public FCTDatHang()
        {
            InitializeComponent();
            busSP = new BUS_SanPham();
        }
      
        private void FCTDatHang_Load(object sender, EventArgs e)
        {
            //HIen thi ds cac sp len cb
            busSP.HienThiDSSP(cbSP);
            co = true;
            txtMaDH.Text = maDH.ToString();
            //Table co 4 cot
            tbDonHang = new DataTable();
            tbDonHang.Columns.Add("ProductID");
            tbDonHang.Columns.Add("UnitPrice");
            tbDonHang.Columns.Add("Quantity");
            tbDonHang.Columns.Add("DisCount");
            //Dua dttb vào dg
            dGSP.DataSource = tbDonHang;
            dGSP.Columns[0].Width = (int)(dGSP.Width * 0.15);
            dGSP.Columns[1].Width = (int)(dGSP.Width * 0.2);
            dGSP.Columns[2].Width = (int)(dGSP.Width * 0.2);
            dGSP.Columns[3].Width = (int)(dGSP.Width * 0.2);

        }
        private void btThem_Click(object sender, EventArgs e)
        {
            DataRow r;
            bool kt = true;
            foreach (DataRow item in tbDonHang.Rows)
            {
                if (cbSP.SelectedValue.ToString() == item[0].ToString())
                {
                    // da co
                    item[2] = (int.Parse(item[2].ToString())
                        + Convert.ToUInt32(numSoLuong.Value)).ToString();
                    kt = false;
                    break;
                }
            }
            //them 1 dong
            if (kt)
            {
                
                //Tao moi 1 dong
                r = tbDonHang.NewRow();
                //Thiet lap thuoc tinh cho dong
                r[0] = int.Parse(cbSP.SelectedValue.ToString()); // ma
                r[1] = int.Parse(txtDonGia.Text.Replace(".", ""));
                r[2] = Convert.ToUInt32(numSoLuong.Value);  
                r[3] = int.Parse(txtGiamGia.Text);
                tbDonHang.Rows.Add(r); 
            }
        }
        private void cbSP_SelectedIndexChanged(object sender, EventArgs e)
        {
            Product p;
            int maSP ;
            //Lay thong tin cua sp
            if (co)
            {
                maSP = Int32.Parse(cbSP.SelectedValue.ToString());
                p = busSP.LayThongTinSP(maSP);
                //hien thi ra tb
                txtDonGia.Text = p.UnitPrice.ToString();
                txtLoaiSP.Text = p.Category.CategoryName.ToString();
                txtNhaCC.Text = p.Supplier.CompanyName.ToString();
            }

        }

        private void btTaoDonHang_Click(object sender, EventArgs e)
        {
            //Luu xuong db
            BUS_DonHang busDH = new BUS_DonHang();
            if (busDH.ThemCTDH(maDH, tbDonHang))
            {
                FCTDonHang f = new FCTDonHang();
                f.maDH = this.maDH;
                this.Close();
                chuyenForm.Close();
                f.Show();
            }
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dGSP_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dGSP.Rows.Count)
            {
                //FCTDonHang f = new FCTDonHang();
                //this.maDH = f.maDH;
                //txtMaDH.Text = this.maDH.ToString();
                txtDonGia.Text = dGSP.Rows[e.RowIndex].Cells["UnitPrice"].Value.ToString();
                numSoLuong.Value = int.Parse(dGSP.Rows[e.RowIndex].Cells[2].Value.ToString());
                txtGiamGia.Text = dGSP.Rows[e.RowIndex].Cells[3].Value.ToString();
            }
        }
    }
}
