﻿using BTCN_PhamAnhDao_1851050029.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTCN_PhamAnhDao_1851050029
{
    public partial class FQuanLyDonHang : Form
    {
        BUS_DonHang bDH;
        public FQuanLyDonHang()
        {
            InitializeComponent();
            bDH = new BUS_DonHang();
        }

        private void HienThiDLLenDg()
        {
            gVDH.DataSource = null;
            bDH.HienThiDSDonHang(gVDH);
            gVDH.Columns[0].Width = (int)(gVDH.Width * 0.15);
            gVDH.Columns[1].Width = (int)(gVDH.Width * 0.2);
            gVDH.Columns[2].Width = (int)(gVDH.Width * 0.2);
            gVDH.Columns[3].Width = (int)(gVDH.Width * 0.2);
           
        }

        private void FQuanLyDonHang_Load(object sender, EventArgs e)
        {
            HienThiDLLenDg();
            bDH.HienThiDSNV(cbNhanVien);
            bDH.HienThiDSKH(cbKhachHang);
        }

        private void gVDH_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < gVDH.Rows.Count)
            {
                txtMaDH.Enabled = false;
                txtMaDH.Text = gVDH.Rows[e.RowIndex].Cells["OrderID"].Value.ToString();
                dtpNgayDatHang.Text = gVDH.Rows[e.RowIndex].Cells[1].Value.ToString();
                cbNhanVien.Text = gVDH.Rows[e.RowIndex].Cells[2].Value.ToString();
                cbKhachHang.Text = gVDH.Rows[e.RowIndex].Cells[3].Value.ToString();
            }
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            Order donHang = new Order();
           // donHang.OrderID = int.Parse(txtMaDH.Text);
            //Kiem tra ma don hang có chinh xac khong
            donHang.OrderDate = dtpNgayDatHang.Value;
            donHang.EmployeeID = int.Parse(cbNhanVien.SelectedValue.ToString());
            donHang.CustomerID = cbKhachHang.SelectedValue.ToString();
            bDH.ThemDonHang(donHang);
            //Cap nhat lai dg
            bDH.HienThiDSDonHang(gVDH);

        }

        private void btSua_Click(object sender, EventArgs e)
        {
            //Lay thong tin don hang sua
            Order d = new Order();
            d.OrderID = int.Parse(txtMaDH.Text);
            d.OrderDate = dtpNgayDatHang.Value;
            d.EmployeeID = Int32.Parse(cbNhanVien.SelectedValue.ToString());
            d.CustomerID = cbKhachHang.SelectedValue.ToString();

            if (bDH.CapNhatDonHang(d))
            {
                bDH.HienThiDSDonHang(gVDH);
            }
            else
                MessageBox.Show("Lỗi đơn hàng");
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            Order d = new Order();
            d.OrderID = int.Parse(txtMaDH.Text);
            
            if (bDH.Xoa(d))
            {
                bDH.HienThiDSDonHang(gVDH);
            }
            else
                MessageBox.Show("Lỗi xóa đơn hàng");
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void gVDH_DoubleClick(object sender, EventArgs e)
        {
            int ma;
            //Lay ma don hang
            ma = int.Parse(gVDH.CurrentRow.Cells[0].Value.ToString());
            //Truyen CTDH
            FCTDonHang f = new FCTDonHang();
            f.maDH = ma;
            f.ShowDialog();
        }
    }
}
