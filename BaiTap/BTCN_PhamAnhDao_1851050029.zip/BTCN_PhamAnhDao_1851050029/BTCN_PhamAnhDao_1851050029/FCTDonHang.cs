﻿using BTCN_PhamAnhDao_1851050029.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTCN_PhamAnhDao_1851050029
{
    
    public partial class FCTDonHang : Form
    {
        public int maDH;
        BUS_DonHang bDH;

        public FCTDonHang()
        {
            InitializeComponent();
            bDH = new BUS_DonHang();
        }
        public void LayDSCTDH(int ma)
        {
            gVCTDH.DataSource = null;
            bDH.HienThiDSCTDH(gVCTDH,ma);
            gVCTDH.Columns[0].Width = (int)(gVCTDH.Width * 0.2);
            gVCTDH.Columns[1].Width = (int)(gVCTDH.Width * 0.25);
            gVCTDH.Columns[2].Width = (int)(gVCTDH.Width * 0.25);
            gVCTDH.Columns[3].Width = (int)(gVCTDH.Width * 0.25);
        }

        private void FCTDonHang_Load(object sender, EventArgs e)
        {
            LayDSCTDH(maDH);        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btThem_Click(object sender, EventArgs e)
        {
           
            FCTDatHang f = new FCTDatHang();
            f.maDH = this.maDH;
            f.ChuyenForm = this;
            this.Close();
            f.Show();
        }
    }
}
