﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTCN_PhamAnhDao_1851050029.DAO
{
    class DAO_SanPham
    {
        //Lien ket DB
        NorthwindEntities1 db;

        public DAO_SanPham()
        {
            db = new NorthwindEntities1();
        }

        //Lay ds san pham
        public dynamic LayDSSP()
        {
            var ds = db.Products.Select(s => new {
                s.ProductID,
                s.ProductName,
                s.UnitPrice,
                s.QuantityPerUnit,
                s.Category.CategoryName,
                s.Supplier.CompanyName
            }).ToList();

            return ds;
        }
        
        public dynamic LayDSLoaiSP()
        {
            var ds = db.Categories.Select(s => new {
                s.CategoryID,
                s.CategoryName
            }).ToList();

            return ds;
        }

        public dynamic LayDSNCC()
        {
            var ds = db.Suppliers.Select(s => new {
                s.SupplierID,
                s.CompanyName
            }).ToList();

            return ds;
        }
        public Product LayThongTinSP(int maSP)
        {
            Product p = db.Products.FirstOrDefault(s => s.ProductID == maSP);
            return p;
        }
        //
    }
}
