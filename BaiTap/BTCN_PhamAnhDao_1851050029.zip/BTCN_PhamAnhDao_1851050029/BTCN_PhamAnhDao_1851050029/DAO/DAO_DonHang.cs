﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTCN_PhamAnhDao_1851050029.DAO
{

    class DAO_DonHang
    {
        NorthwindEntities1 db;

        public DAO_DonHang()
        {
            db = new NorthwindEntities1();
        }
        public dynamic LayDSDonHang()
        {
            var ds = db.Orders.Select(s => new {
                s.OrderID,
                s.OrderDate,
                s.Employee.LastName,
                s.Customer.CompanyName
            }).ToList();

            return ds;
        }
        public dynamic LayDSNV()
        {
            var ds = db.Employees.Select(s => new {
                s.EmployeeID,
                s.LastName,
            }).ToList();

            return ds;
        }
        public dynamic LayDSKH()
        {
            var ds = db.Customers.Select(s => new {
                s.CustomerID,
                s.CompanyName
            }).ToList();

            return ds;
        }

        public void ThemDonHang(Order donHang)
        {
            //Ma don hang tu tang
            db.Orders.Add(donHang);
            db.SaveChanges();
        }

        public bool KiemTraDH(Order d)
        {
            
            Order donHang = db.Orders.Find(d.OrderID);
            if (donHang != null)
                return true;
            else
                return false;
        }
        public void SuaDH(Order d)
        {
            Order donHang;
            donHang = db.Orders.Find(d.OrderID);
                donHang.OrderDate = d.OrderDate;
                donHang.EmployeeID = d.EmployeeID;
                donHang.CustomerID = d.CustomerID;
                db.SaveChanges();
        }

        public void Xoa(Order d)
        {
            Order donHang;
            donHang = db.Orders.Find(d.OrderID);
            db.Orders.Remove(donHang);
            db.SaveChanges();
        }

        //Chi tiet don hang
        public dynamic DSCTDH(int maDH)
        {
            var ds = db.Order_Details.Where(s => s.OrderID == maDH)
                .Select(s => new
                {
                    s.OrderID,
                    s.Product.ProductName,
                    s.UnitPrice,
                    s.Quantity
                }).ToList();
            return ds;

        }
        
        public bool  ThemCTDH(Order_Detail d)
        {
            bool trangThai = false;
            int? sl = db.sp_KiemTraCTDH(d.OrderID, d.ProductID).FirstOrDefault();
            //Ktra sp co ton tai chua, neu chua thi moi them
            if ( sl == 0)
            {
                db.Order_Details.Add(d);
                db.SaveChanges();
                trangThai = true;
            }
            return trangThai;
        }
    }
}
