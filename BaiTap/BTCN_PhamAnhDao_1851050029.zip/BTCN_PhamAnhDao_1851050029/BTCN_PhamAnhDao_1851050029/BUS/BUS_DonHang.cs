﻿using BTCN_PhamAnhDao_1851050029.DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;

namespace BTCN_PhamAnhDao_1851050029.BUS
{
   
    class BUS_DonHang
    {
        DAO_DonHang dDH;
        public BUS_DonHang()
        {
            dDH = new DAO_DonHang();
        }

        public void HienThiDSDonHang(DataGridView dg)
        {
            dg.DataSource = dDH.LayDSDonHang();
        }
        public void HienThiDSNV(ComboBox cb)
        {
            cb.DataSource = dDH.LayDSNV();
            cb.DisplayMember = "LastName";
            cb.ValueMember = "EmployeeID";
        }

        public void HienThiDSCTDH(DataGridView dg, int maDH)
        {
            dg.DataSource = dDH.DSCTDH(maDH);
        }
        public void HienThiDSKH(ComboBox cb)
        {
            cb.DataSource = dDH.LayDSKH();
            cb.DisplayMember = "CompanyName";
            cb.ValueMember = "CustomerID";
        }

        public void ThemDonHang(Order donHang)
        {
            try
            {
                dDH.ThemDonHang(donHang);
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public bool CapNhatDonHang(Order d)
        {
            //Ktra maDH co khong
            //Xu ly
           
                if (dDH.KiemTraDH(d))
                {
                try
                {
                    dDH.SuaDH(d);
                    return true;
                }
                catch (DbUpdateException ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;
                    throw;
                }
                }
                else
                    return false;
        }

        public bool Xoa(Order d)
        {
            if (dDH.KiemTraDH(d))
            {
                try
                {
                    dDH.Xoa(d);
                    return true;
                }
                catch (DbUpdateException ex)
                {
                    MessageBox.Show(ex.Message);
                    return false;
                }
            }
            else
                return false;
        }
        public bool ThemCTDH(int maDH, DataTable tbDonHang)
        {
            bool ketQuaraVe = false;
            using (var trans = new TransactionScope ())
            {
                try
                {
                    foreach (DataRow item in tbDonHang.Rows)
                    {
                        Order_Detail d = new Order_Detail();
                        d.OrderID = maDH;
                        d.ProductID = Int32.Parse(item[0].ToString());
                        d.UnitPrice = Decimal.Parse(item[1].ToString());
                        d.Quantity = short.Parse(item[2].ToString());
                        d.Discount = float.Parse(item[0].ToString());
                        if (!dDH.ThemCTDH(d))
                        {
                            throw new Exception("Đã tồn tại sản phẩm " + d.ProductID);
                        }
                    }
                    trans.Complete();
                    ketQuaraVe = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    ketQuaraVe = false;
                    throw;
                } 
            }

            return ketQuaraVe;

        }
        ////

       
    }
}
