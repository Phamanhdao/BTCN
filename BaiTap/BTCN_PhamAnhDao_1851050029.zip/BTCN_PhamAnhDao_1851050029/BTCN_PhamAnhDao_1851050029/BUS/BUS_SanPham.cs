﻿using BTCN_PhamAnhDao_1851050029.DAO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTCN_PhamAnhDao_1851050029.BUS
{
    class BUS_SanPham
    {
        DAO_SanPham dSP;

        public BUS_SanPham()
        {
            dSP = new DAO_SanPham();
        }
        //Hien thi ds san pham
        public void HienThiDSSPLenDg(DataGridView dg)
        {
            dg.DataSource = dSP.LayDSSP();
        }
        
        public void HienThiDSSP(ComboBox cb)
        {
            cb.DataSource = dSP.LayDSSP();
            cb.DisplayMember = "ProductName";
            cb.ValueMember = "ProductID";
        }

        public void HienThiDSLoaiSP(ComboBox cb)
        {
            cb.DataSource = dSP.LayDSLoaiSP();
            cb.DisplayMember = "CategoryName";
            cb.ValueMember = "CategoryID";
        }

        public void HienThiDSNCC(ComboBox cb)
        {
            cb.DataSource = dSP.LayDSNCC();
            cb.DisplayMember = "SuplierID";
            cb.ValueMember = "CompanyName";
        }

        public Product LayThongTinSP(int maSP)
        {
            Product p = dSP.LayThongTinSP(maSP);
            return p;
        }
    }
}
