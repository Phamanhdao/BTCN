﻿using BTCN_PhamAnhDao_1851050029.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTCN_PhamAnhDao_1851050029
{
    public partial class FQuanLySanPham : Form
    {
        BUS_SanPham busSP;
        public FQuanLySanPham()
        {
            InitializeComponent();
            busSP = new BUS_SanPham();
        }

        private void HienThiDLLenDg()
        {
            gVSanPham.DataSource = null;
            busSP.HienThiDSSPLenDg(gVSanPham);
            gVSanPham.Columns[0].Width = (int)(gVSanPham.Width * 0.15);
            gVSanPham.Columns[1].Width = (int)(gVSanPham.Width * 0.2);
            gVSanPham.Columns[2].Width = (int)(gVSanPham.Width * 0.2);
            gVSanPham.Columns[3].Width = (int)(gVSanPham.Width * 0.2);
            gVSanPham.Columns[4].Width = (int)(gVSanPham.Width * 0.2);
            gVSanPham.Columns[5].Width = (int)(gVSanPham.Width * 0.2);
        }
        private void FQuanLySanPham_Load(object sender, EventArgs e)
        {
            HienThiDLLenDg();
            busSP.HienThiDSNCC(cbNCC);
            busSP.HienThiDSLoaiSP(cbLoaiSP);
        }

        private void gVSanPham_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < gVSanPham.Rows.Count)
            {
               // txtMaDH.Enabled = false;
                txtTenSP.Text = gVSanPham.Rows[e.RowIndex].Cells["ProductName"].Value.ToString();
                txtSoLuong.Text = gVSanPham.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtDonGia.Text = gVSanPham.Rows[e.RowIndex].Cells[2].Value.ToString();
                txtSoLuong.Text= gVSanPham.Rows[e.RowIndex].Cells[3].Value.ToString();
                cbLoaiSP.Text = gVSanPham.Rows[e.RowIndex].Cells[4].Value.ToString();
                cbNCC.Text = gVSanPham.Rows[e.RowIndex].Cells[5].Value.ToString();
            }

        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        
    }
}
